import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile } from '../types/index.js';

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<void>;
  signup: (name: string, email: string, company?: string, jobTitle?: string) => Promise<void>;
  logout: () => void;
  upgradePlan: () => void;
  refreshUser: () => Promise<void>;
  updateUserCredits: (newCredits: number) => void;
  updateProfile: (updatedData: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('mailcraft_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const refreshUser = async () => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
        }
      }
    } catch (e) {
      console.error('Error fetching user:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, [token]);

  const login = async (email: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.token && data.user) {
        setToken(data.token);
        localStorage.setItem('mailcraft_token', data.token);
        setUser(data.user);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (name: string, email: string, company?: string, jobTitle?: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, company, jobTitle }),
      });
      const data = await res.json();
      if (data.token && data.user) {
        setToken(data.token);
        localStorage.setItem('mailcraft_token', data.token);
        setUser(data.user);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('mailcraft_token');
  };

  const upgradePlan = () => {
    if (user) {
      const upgraded: UserProfile = {
        ...user,
        plan: 'Premium',
        creditsRemaining: 99999,
        maxCredits: 99999,
      };
      setUser(upgraded);
    }
  };

  const updateUserCredits = (newCredits: number) => {
    if (user) {
      setUser({ ...user, creditsRemaining: newCredits });
    }
  };

  const updateProfile = (updatedData: Partial<UserProfile>) => {
    if (user) {
      setUser({ ...user, ...updatedData });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout,
        upgradePlan,
        refreshUser,
        updateUserCredits,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
