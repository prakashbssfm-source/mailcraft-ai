import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { useTheme } from '../../context/ThemeContext.js';
import {
  Sparkles,
  Sun,
  Moon,
  Zap,
  User,
  LogOut,
  ShieldCheck,
  LayoutDashboard,
  Menu,
  X,
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onToggleMobileSidebar: () => void;
  isMobileSidebarOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onToggleMobileSidebar,
  isMobileSidebarOpen,
}) => {
  const { user, isAuthenticated, logout, upgradePlan } = useAuth();
  const { theme, setTheme } = useTheme();

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Mobile Menu Toggle & Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileSidebar}
            className="md:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Toggle menu"
          >
            {isMobileSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div
            onClick={() => onNavigate(isAuthenticated ? 'dashboard' : 'landing')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform duration-200">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight text-white flex items-center gap-1.5">
                MailCraft <span className="text-xs px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 font-mono border border-indigo-500/20">AI</span>
              </span>
            </div>
          </div>
        </div>

        {/* Center: Navigation Links for Public View */}
        {!isAuthenticated && (
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
            <button
              onClick={() => onNavigate('landing')}
              className={`hover:text-white transition-colors ${currentView === 'landing' ? 'text-indigo-400' : ''}`}
            >
              Overview
            </button>
            <button
              onClick={() => onNavigate('pricing')}
              className={`hover:text-white transition-colors ${currentView === 'pricing' ? 'text-indigo-400' : ''}`}
            >
              Pricing
            </button>
            <button
              onClick={() => onNavigate('templates')}
              className={`hover:text-white transition-colors ${currentView === 'templates' ? 'text-indigo-400' : ''}`}
            >
              Templates
            </button>
          </nav>
        )}

        {/* Right Controls */}
        <div className="flex items-center gap-3">
          {/* AI Credits Badge */}
          {isAuthenticated && user && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300">
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
              <span className="font-semibold text-white">
                {user.plan === 'Premium' ? 'Unlimited Credits' : `${user.creditsRemaining} / ${user.maxCredits} AI Credits`}
              </span>
            </div>
          )}

          {/* Theme Toggle Button */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors"
            title="Toggle Theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-indigo-400" />}
          </button>

          {/* Auth State Actions */}
          {isAuthenticated ? (
            <div className="flex items-center gap-2">
              {user?.plan !== 'Premium' && (
                <button
                  onClick={() => {
                    upgradePlan();
                    onNavigate('pricing');
                  }}
                  className="hidden md:flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md shadow-orange-500/20 hover:opacity-95 transition-opacity"
                >
                  <Zap className="w-3.5 h-3.5" />
                  Upgrade Pro
                </button>
              )}

              <div className="relative group">
                <button
                  onClick={() => onNavigate('profile')}
                  className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 overflow-hidden flex items-center justify-center text-slate-200 font-semibold hover:border-indigo-500 transition-colors"
                >
                  {user?.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    user?.name?.charAt(0).toUpperCase() || 'U'
                  )}
                </button>

                {/* Dropdown Menu */}
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-2 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all duration-150 transform origin-top-right z-50">
                  <div className="px-3 py-2 border-b border-slate-800 mb-1">
                    <p className="text-sm font-semibold text-white truncate">{user?.name}</p>
                    <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                    <span className="inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {user?.plan} Plan
                    </span>
                  </div>

                  <button
                    onClick={() => onNavigate('dashboard')}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                  >
                    <LayoutDashboard className="w-4 h-4 text-indigo-400" />
                    Dashboard
                  </button>

                  <button
                    onClick={() => onNavigate('profile')}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                  >
                    <User className="w-4 h-4 text-purple-400" />
                    Profile & Account
                  </button>

                  {user?.role === 'admin' && (
                    <button
                      onClick={() => onNavigate('admin')}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      Admin Control Panel
                    </button>
                  )}

                  <div className="border-t border-slate-800 my-1"></div>

                  <button
                    onClick={() => {
                      logout();
                      onNavigate('landing');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Log Out
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('login')}
                className="text-xs font-semibold px-3.5 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('signup')}
                className="text-xs font-semibold px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/25 transition-all"
              >
                Start Free
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
