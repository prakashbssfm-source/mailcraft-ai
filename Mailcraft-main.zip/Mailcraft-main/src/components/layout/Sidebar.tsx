import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import {
  LayoutDashboard,
  Sparkles,
  Reply,
  Wand2,
  Heading,
  BookmarkCheck,
  History as HistoryIcon,
  Crown,
  Settings,
  ShieldAlert,
  User,
  LogOut,
  Zap,
  FileText,
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { user, logout } = useAuth();

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'generate', label: 'Generate Email', icon: Sparkles, highlight: true },
    { id: 'reply', label: 'Reply Assistant', icon: Reply },
    { id: 'improve', label: 'Improve Email', icon: Wand2 },
    { id: 'subject', label: 'Subject Generator', icon: Heading },
    { id: 'templates', label: 'Templates', icon: FileText },
    { id: 'saved', label: 'Saved Emails', icon: BookmarkCheck },
    { id: 'history', label: 'Email History', icon: HistoryIcon },
    { id: 'pricing', label: 'Pricing & Plans', icon: Crown },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  if (user?.role === 'admin') {
    navItems.push({ id: 'admin', label: 'Admin Panel', icon: ShieldAlert });
  }

  const handleNav = (viewId: string) => {
    onNavigate(viewId);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm md:hidden"
        />
      )}

      {/* Sidebar element */}
      <aside
        className={`fixed md:sticky top-16 z-40 h-[calc(100vh-4rem)] w-64 shrink-0 bg-slate-950/90 border-r border-slate-800/80 p-4 flex flex-col justify-between transition-transform duration-300 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="space-y-6 overflow-y-auto pr-1">
          {/* Main Navigation Links */}
          <div className="space-y-1">
            <p className="px-3 text-[11px] font-semibold tracking-wider text-slate-500 uppercase mb-2">
              Core Applications
            </p>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600/90 to-purple-600/90 text-white shadow-lg shadow-indigo-600/20'
                      : item.highlight
                      ? 'text-indigo-300 hover:text-white hover:bg-slate-900 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom User Card / Upgrade Box */}
        <div className="pt-4 border-t border-slate-800/80 space-y-3">
          {user && user.plan !== 'Premium' && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-purple-950/40 to-slate-900 border border-indigo-500/30 text-center">
              <div className="flex justify-center mb-1.5">
                <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
                  <Zap className="w-4 h-4" />
                </div>
              </div>
              <h4 className="text-xs font-bold text-white">Upgrade to Pro</h4>
              <p className="text-[11px] text-slate-400 mt-1">Get unlimited emails & priority AI speed.</p>
              <button
                onClick={() => handleNav('pricing')}
                className="mt-2.5 w-full py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition-all"
              >
                Upgrade Plan
              </button>
            </div>
          )}

          <div className="flex items-center justify-between px-2 pt-1">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-semibold text-xs text-indigo-400 shrink-0">
                {user?.name?.charAt(0) || 'M'}
              </div>
              <div className="truncate">
                <p className="text-xs font-medium text-white truncate">{user?.name || 'User'}</p>
                <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
              </div>
            </div>
            <button
              onClick={() => logout()}
              className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-900 transition-colors"
              title="Log Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
