import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { jsPDF } from 'jspdf';
import {
  Sparkles,
  Copy,
  Download,
  BookmarkPlus,
  RotateCcw,
  Check,
  Globe2,
  Sliders,
  Type,
  FileText,
  User,
  Building,
  Target,
  ListOrdered,
  Zap,
} from 'lucide-react';
import {
  EmailCategory,
  Language,
  Tone,
  EmailLength,
  EmailGeneratorInput,
  GeneratedEmailOutput,
} from '../types/index.js';

interface EmailGeneratorViewProps {
  onShowToast: (msg: string) => void;
  prefillTemplate?: { subject: string; body: string; category?: string };
}

export const EmailGeneratorView: React.FC<EmailGeneratorViewProps> = ({
  onShowToast,
  prefillTemplate,
}) => {
  const { user, updateUserCredits } = useAuth();

  const categories: EmailCategory[] = [
    'Job Application',
    'Leave Request',
    'Business Proposal',
    'Complaint',
    'Payment Reminder',
    'Meeting Request',
    'Follow-up',
    'Thank You',
    'Resignation',
    'Customer Support',
    'Scholarship Request',
    'Internship Request',
    'Recommendation Request',
    'Cold Email',
    'Sales Pitch',
    'Promotion',
    'Custom',
  ];

  const languages: Language[] = ['English', 'Hindi', 'Marathi', 'Spanish', 'French', 'German'];

  const tones: Tone[] = [
    'Professional',
    'Formal',
    'Friendly',
    'Persuasive',
    'Confident',
    'Empathetic',
    'Apologetic',
    'Short',
  ];

  const lengths: EmailLength[] = ['Short', 'Medium', 'Long'];

  const [category, setCategory] = useState<EmailCategory>('Business Proposal');
  const [recipientName, setRecipientName] = useState<string>('TechCorp Executive');
  const [companyName, setCompanyName] = useState<string>('TechCorp Global');
  const [purpose, setPurpose] = useState<string>('Propose Q3 AI Automation co-marketing partnership');
  const [keyPoints, setKeyPoints] = useState<string>(
    '1. Proven 45% onboarding speedup\n2. Joint revenue share opportunity\n3. Request 15-min call this Thursday'
  );
  const [additionalInstructions, setAdditionalInstructions] = useState<string>('');
  const [language, setLanguage] = useState<Language>('English');
  const [tone, setTone] = useState<Tone>('Professional');
  const [length, setLength] = useState<EmailLength>('Medium');
  const [senderName, setSenderName] = useState<string>(user?.name || 'Sarah Jenkins');
  const [senderTitle, setSenderTitle] = useState<string>(user?.jobTitle || 'Head of Growth');

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [output, setOutput] = useState<GeneratedEmailOutput | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [saved, setSaved] = useState<boolean>(false);

  useEffect(() => {
    if (prefillTemplate) {
      if (prefillTemplate.category && categories.includes(prefillTemplate.category as any)) {
        setCategory(prefillTemplate.category as EmailCategory);
      }
      setPurpose(prefillTemplate.subject);
      setKeyPoints(prefillTemplate.body);
    }
  }, [prefillTemplate]);

  const handleGenerate = async () => {
    if (!purpose.trim()) {
      onShowToast('Please enter the purpose of the email.');
      return;
    }

    setIsGenerating(true);
    setCopied(false);
    setSaved(false);

    const payload: EmailGeneratorInput = {
      category,
      recipientName,
      companyName,
      purpose,
      keyPoints,
      additionalInstructions,
      language,
      tone,
      length,
      senderName,
      senderTitle,
    };

    try {
      const res = await fetch('/api/ai/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, userId: user?.id || 'usr_demo' }),
      });

      const data = await res.json();
      if (res.ok && data.email) {
        setOutput(data.email);
        if (data.user && typeof data.user.creditsRemaining === 'number') {
          updateUserCredits(data.user.creditsRemaining);
        }
        onShowToast('Email generated successfully!');
      } else if (res.status === 402) {
        onShowToast('AI Credits exhausted! Please upgrade your plan.');
      } else {
        onShowToast(data.error || 'Failed to generate email');
      }
    } catch (err) {
      console.error(err);
      onShowToast('Error connecting to MailCraft AI server');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output.fullContent);
    setCopied(true);
    onShowToast('Copied full email to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = async () => {
    if (!output) return;
    try {
      const res = await fetch('/api/saved-emails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id || 'usr_demo',
          title: output.subject,
          subject: output.subject,
          body: output.body,
          closing: output.closing,
          signature: output.signature,
          fullContent: output.fullContent,
          category: output.category,
          tone: output.tone,
          language: output.language,
        }),
      });

      if (res.ok) {
        setSaved(true);
        onShowToast('Email saved to your private library!');
      }
    } catch (err) {
      onShowToast('Failed to save email.');
    }
  };

  const handleDownloadPDF = () => {
    if (!output) return;
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('MailCraft AI Generated Email', 14, 20);

    doc.setFontSize(12);
    doc.text(`Subject: ${output.subject}`, 14, 32);

    doc.setFontSize(10);
    doc.text(`Category: ${output.category} | Tone: ${output.tone} | Language: ${output.language}`, 14, 40);

    const splitBody = doc.splitTextToSize(output.body, 180);
    doc.text(splitBody, 14, 52);

    const bodyHeight = splitBody.length * 6;
    doc.text(output.closing, 14, 52 + bodyHeight + 10);
    doc.text(output.signature, 14, 52 + bodyHeight + 18);

    doc.save(`${output.subject.replace(/[^a-z0-9]/gi, '_')}.pdf`);
    onShowToast('PDF exported successfully!');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <Sparkles className="w-7 h-7 text-indigo-400" /> Advanced AI Email Generator
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure categories, tone, language, and key points to craft bespoke executive communication.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Form Controls */}
        <div className="lg:col-span-6 space-y-6 bg-slate-900/80 p-6 rounded-2xl border border-slate-800">
          {/* Email Category */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-400" /> Email Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as EmailCategory)}
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-none"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Names Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-purple-400" /> Recipient Name
              </label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="e.g. John Doe"
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-pink-400" /> Company / Organization
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g. Acme Corp"
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Purpose */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-emerald-400" /> Purpose / Primary Goal *
            </label>
            <input
              type="text"
              required
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="e.g. Request leave approval for family function"
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Key Points */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
              <ListOrdered className="w-3.5 h-3.5 text-amber-400" /> Key Points to Include
            </label>
            <textarea
              rows={3}
              value={keyPoints}
              onChange={(e) => setKeyPoints(e.target.value)}
              placeholder="List specific details or metrics..."
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Tone & Language & Length Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center gap-1">
                <Sliders className="w-3 h-3 text-indigo-400" /> Tone
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value as Tone)}
                className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {tones.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center gap-1">
                <Globe2 className="w-3 h-3 text-purple-400" /> Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {languages.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center gap-1">
                <Type className="w-3 h-3 text-pink-400" /> Length
              </label>
              <select
                value={length}
                onChange={(e) => setLength(e.target.value as EmailLength)}
                className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:border-indigo-500 focus:outline-none"
              >
                {lengths.map((len) => (
                  <option key={len} value={len}>
                    {len}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Sender Signature Inputs */}
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Your Name</label>
              <input
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Your Title</label>
              <input
                type="text"
                value={senderTitle}
                onChange={(e) => setSenderTitle(e.target.value)}
                className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-indigo-600/25 transition-all flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Crafting with Gemini AI...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" /> Generate Email
              </>
            )}
          </button>
        </div>

        {/* Right Output Section */}
        <div className="lg:col-span-6 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Generated Email Canvas</h3>
            {output && (
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20">
                AI Ready
              </span>
            )}
          </div>

          <div className="flex-1 p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 min-h-[420px] flex flex-col justify-between">
            {output ? (
              <div className="space-y-4">
                {/* Subject Header */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="text-xs font-semibold text-indigo-400 block mb-0.5">Subject</span>
                  <p className="text-sm font-bold text-white">{output.subject}</p>
                </div>

                {/* Email Body */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/60 text-xs text-slate-200 whitespace-pre-line leading-relaxed font-sans min-h-[220px]">
                  {output.body}
                  <div className="mt-6 pt-4 border-t border-slate-900 text-slate-300">
                    <p className="font-medium">{output.closing}</p>
                    <p className="font-bold text-white mt-1 whitespace-pre-line">{output.signature}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <Sparkles className="w-6 h-6 animate-pulse" />
                </div>
                <h4 className="text-sm font-bold text-white">Your AI Generated Email will appear here</h4>
                <p className="text-xs text-slate-400 max-w-sm">
                  Fill in the details on the left and click "Generate Email" to create a bespoke email.
                </p>
              </div>
            )}

            {/* Action Toolbar */}
            {output && (
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>

                  <button
                    onClick={handleDownloadPDF}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-purple-400" /> PDF
                  </button>

                  <button
                    onClick={handleSave}
                    disabled={saved}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-colors"
                  >
                    {saved ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <BookmarkPlus className="w-3.5 h-3.5 text-amber-400" />}
                    {saved ? 'Saved' : 'Save'}
                  </button>
                </div>

                <button
                  onClick={handleGenerate}
                  className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-xs transition-colors"
                  title="Regenerate"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
