import React, { useState } from 'react';
import { Heading, Copy, Check, Sparkles, TrendingUp, RotateCcw } from 'lucide-react';
import { SubjectLineVariant } from '../types/index.js';

interface SubjectGeneratorViewProps {
  onShowToast: (msg: string) => void;
}

export const SubjectGeneratorView: React.FC<SubjectGeneratorViewProps> = ({ onShowToast }) => {
  const [context, setContext] = useState<string>('Q3 Enterprise AI Automation Proposal & Demo Follow-up');
  const [targetAudience, setTargetAudience] = useState<string>('VP of Technology / Enterprise Procurement');
  const [loading, setLoading] = useState<boolean>(false);
  const [subjects, setSubjects] = useState<SubjectLineVariant[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!context.trim()) {
      onShowToast('Please enter the email purpose/context.');
      return;
    }

    setLoading(true);
    setCopiedId(null);

    try {
      const res = await fetch('/api/ai/generate-subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context, targetAudience }),
      });

      const data = await res.json();
      if (res.ok && data.subjects) {
        setSubjects(data.subjects);
        onShowToast('Generated 10 subject lines!');
      } else {
        onShowToast('Failed to generate subject lines');
      }
    } catch (err) {
      onShowToast('Error connecting to subject line generator');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast('Copied subject line to clipboard!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <Heading className="w-7 h-7 text-emerald-400" /> Smart Subject Line Generator
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Generate 10 high-converting subject line variations optimized for high open rates and engagement.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs */}
        <div className="lg:col-span-5 space-y-5 bg-slate-900/80 p-6 rounded-2xl border border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Email Topic / Purpose *
            </label>
            <textarea
              rows={4}
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="e.g. Request meeting for enterprise partnership..."
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Target Audience / Persona
            </label>
            <input
              type="text"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="e.g. Senior Marketing Executives"
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-emerald-600/25 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              'Generating 10 Variations...'
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> Generate 10 Subject Lines
              </>
            )}
          </button>
        </div>

        {/* Right Output Grid */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">10 Optimized Subject Variations</h3>
            {subjects.length > 0 && (
              <button
                onClick={handleGenerate}
                className="text-xs text-emerald-400 hover:underline flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Regenerate
              </button>
            )}
          </div>

          {subjects.length > 0 ? (
            <div className="space-y-3">
              {subjects.map((sub, idx) => (
                <div
                  key={sub.id}
                  className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/30 transition-all flex items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white mb-1">{sub.subject}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {sub.tone}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-0.5">
                          <TrendingUp className="w-3 h-3" /> Est. {sub.estimatedOpenRate}% Open Rate
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleCopy(sub.id, sub.subject)}
                    className="p-2 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs shrink-0 transition-colors"
                    title="Copy subject line"
                  >
                    {copiedId === sub.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mx-auto">
                <Heading className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white">Generate High-Converting Subjects</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Enter your topic on the left to review 10 custom subject line variations with open-rate predictions.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
