import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  Sparkles,
  BookmarkCheck,
  Zap,
  Layers,
  ArrowUpRight,
  Plus,
  Reply,
  Wand2,
  Heading,
  Clock,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
} from 'recharts';
import { WeeklyUsageData, MonthlyUsageData, EmailHistoryItem } from '../types/index.js';

interface DashboardViewProps {
  onNavigate: (view: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [weeklyUsage, setWeeklyUsage] = useState<WeeklyUsageData[]>([]);
  const [monthlyUsage, setMonthlyUsage] = useState<MonthlyUsageData[]>([]);
  const [recentHistory, setRecentHistory] = useState<EmailHistoryItem[]>([]);
  const [savedCount, setSavedCount] = useState<number>(0);

  useEffect(() => {
    fetch('/api/user/analytics')
      .then((res) => res.json())
      .then((data) => {
        if (data.weeklyUsage) setWeeklyUsage(data.weeklyUsage);
        if (data.monthlyUsage) setMonthlyUsage(data.monthlyUsage);
      })
      .catch((err) => console.error(err));

    fetch('/api/history')
      .then((res) => res.json())
      .then((data) => {
        if (data.history) setRecentHistory(data.history.slice(0, 5));
      })
      .catch((err) => console.error(err));

    fetch('/api/saved-emails')
      .then((res) => res.json())
      .then((data) => {
        if (data.savedEmails) setSavedCount(data.savedEmails.length);
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-900/60 via-purple-900/40 to-slate-900 border border-indigo-500/30">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Welcome back, {user?.name || 'Executive'} 👋
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Ready to craft your next high-converting email? You have{' '}
            <span className="font-semibold text-amber-300">
              {user?.plan === 'Premium' ? 'Unlimited' : `${user?.creditsRemaining} AI credits`}
            </span>{' '}
            available today.
          </p>
        </div>
        <button
          onClick={() => onNavigate('generate')}
          className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" /> Generate New Email
        </button>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Total Generated</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">142</div>
          <p className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
            <ArrowUpRight className="w-3 h-3" /> +18% this week
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Saved Emails</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <BookmarkCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{savedCount || 12}</div>
          <p className="text-[11px] text-slate-400 mt-1">In your saved library</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">Templates Used</span>
            <div className="p-2 rounded-xl bg-pink-500/10 text-pink-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">48</div>
          <p className="text-[11px] text-slate-400 mt-1">Across 10 categories</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">AI Credits</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {user?.plan === 'Premium' ? '∞' : user?.creditsRemaining ?? 10}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {user?.plan === 'Premium' ? 'Unlimited Pro Plan' : 'Refills monthly'}
          </p>
        </div>
      </div>

      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Chart */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Weekly Email Generation Activity</h3>
            <span className="text-xs text-indigo-400 font-mono">Last 7 Days</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyUsage.length ? weeklyUsage : [
                { day: 'Mon', emailsGenerated: 12 },
                { day: 'Tue', emailsGenerated: 19 },
                { day: 'Wed', emailsGenerated: 25 },
                { day: 'Thu', emailsGenerated: 32 },
                { day: 'Fri', emailsGenerated: 28 },
                { day: 'Sat', emailsGenerated: 14 },
                { day: 'Sun', emailsGenerated: 18 },
              ]}>
                <XAxis dataKey="day" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="emailsGenerated" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly Trend Chart */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Monthly Output Trend</h3>
            <span className="text-xs text-purple-400 font-mono">2026 YTD</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyUsage.length ? monthlyUsage : [
                { month: 'Jan', emailsGenerated: 140 },
                { month: 'Feb', emailsGenerated: 210 },
                { month: 'Mar', emailsGenerated: 310 },
                { month: 'Apr', emailsGenerated: 420 },
                { month: 'May', emailsGenerated: 590 },
                { month: 'Jun', emailsGenerated: 780 },
                { month: 'Jul', emailsGenerated: 940 },
              ]}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="emailsGenerated" stroke="#a855f7" fill="#a855f7" fillOpacity={0.2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick Launch & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Launch Cards */}
        <div className="lg:col-span-1 p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white">Quick AI Workflows</h3>
          <div className="space-y-3">
            <button
              onClick={() => onNavigate('generate')}
              className="w-full p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors">
                    AI Email Generator
                  </h4>
                  <p className="text-[11px] text-slate-400">15+ categories & custom tones</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-colors" />
            </button>

            <button
              onClick={() => onNavigate('reply')}
              className="w-full p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                  <Reply className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-purple-400 transition-colors">
                    Reply Assistant
                  </h4>
                  <p className="text-[11px] text-slate-400">4 distinct reply options</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-purple-400 transition-colors" />
            </button>

            <button
              onClick={() => onNavigate('improve')}
              className="w-full p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-pink-500/10 text-pink-400">
                  <Wand2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-pink-400 transition-colors">
                    Email Draft Improver
                  </h4>
                  <p className="text-[11px] text-slate-400">Grammar, tone & confidence</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-pink-400 transition-colors" />
            </button>

            <button
              onClick={() => onNavigate('subject')}
              className="w-full p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                  <Heading className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">
                    Subject Line Generator
                  </h4>
                  <p className="text-[11px] text-slate-400">10 high-open-rate options</p>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </button>
          </div>
        </div>

        {/* Recent Activity Stream */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Recent Activity</h3>
            <button
              onClick={() => onNavigate('history')}
              className="text-xs font-semibold text-indigo-400 hover:underline"
            >
              View Full History →
            </button>
          </div>

          <div className="space-y-3">
            {recentHistory.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/60 flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{item.subject}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 font-mono">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-1">{item.preview}</p>
                </div>
                <div className="text-[10px] text-slate-500 shrink-0 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(item.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
