import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Crown, CheckCircle2, Zap, ArrowRight, ShieldCheck } from 'lucide-react';

interface PricingViewProps {
  onShowToast: (msg: string) => void;
  onNavigate: (view: string) => void;
}

export const PricingView: React.FC<PricingViewProps> = ({ onShowToast, onNavigate }) => {
  const { user, upgradePlan } = useAuth();

  const handleUpgrade = () => {
    upgradePlan();
    onShowToast('Upgraded to MailCraft Premium! Unlimited AI credits activated.');
    onNavigate('dashboard');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto space-y-8">
      <div className="text-center max-w-2xl mx-auto">
        <span className="text-xs font-bold font-mono px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
          Flexible & Transparent Pricing
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white mt-3">
          Supercharge Your Email Communication
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-2">
          Start free with 10 monthly credits or upgrade to Premium for unlimited AI generation & priority support.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Free Plan */}
        <div className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between space-y-6">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Free Starter</span>
            <div className="text-4xl font-black text-white mt-2">$0 <span className="text-xs text-slate-400 font-normal">/ month</span></div>
            <p className="text-xs text-slate-400 mt-2">Perfect for casual email composition and quick replies.</p>

            <ul className="space-y-3 mt-6 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> 10 AI Email Credits / Month
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Access to 15+ Email Categories
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Basic Reply Assistant & Subject Generator
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Save up to 10 Emails in Library
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Export as PDF
              </li>
            </ul>
          </div>

          <button
            disabled={user?.plan === 'Free'}
            onClick={() => onNavigate('dashboard')}
            className="w-full py-3.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 text-xs font-semibold"
          >
            {user?.plan === 'Free' ? 'Current Active Plan' : 'Select Free'}
          </button>
        </div>

        {/* Premium Plan */}
        <div className="p-8 rounded-3xl bg-gradient-to-b from-indigo-900/80 via-slate-900 to-purple-950/60 border-2 border-indigo-500 relative flex flex-col justify-between space-y-6 shadow-2xl shadow-indigo-600/20">
          <div className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] font-black tracking-wider uppercase shadow-md">
            Most Popular
          </div>

          <div>
            <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1">
              <Crown className="w-4 h-4 text-amber-400" /> MailCraft Pro
            </span>
            <div className="text-4xl font-black text-white mt-2">$19 <span className="text-xs text-slate-400 font-normal">/ month</span></div>
            <p className="text-xs text-slate-300 mt-2">Unlimited power for founders, executives, and growth teams.</p>

            <ul className="space-y-3 mt-6 text-xs text-slate-200 font-medium">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> <span className="font-bold text-white">Unlimited AI Email Generation</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> Priority Gemini 3.6 Speed Models
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> Advanced Email Improver & Quality Metrics
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> Unlimited Saved Emails & Full History Timeline
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> Custom Industry Template Creation
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400" /> Priority Executive Support
              </li>
            </ul>
          </div>

          <button
            onClick={handleUpgrade}
            disabled={user?.plan === 'Premium'}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-pink-500 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
          >
            {user?.plan === 'Premium' ? (
              'Active Pro Subscription'
            ) : (
              <>
                Upgrade to Pro Now <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
