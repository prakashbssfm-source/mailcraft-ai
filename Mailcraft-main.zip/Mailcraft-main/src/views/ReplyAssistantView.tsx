import React, { useState } from 'react';
import { Reply, Copy, Check, Sparkles, Send, ArrowRight } from 'lucide-react';
import { ReplyAssistantOutput } from '../types/index.js';

interface ReplyAssistantViewProps {
  onShowToast: (msg: string) => void;
}

export const ReplyAssistantView: React.FC<ReplyAssistantViewProps> = ({ onShowToast }) => {
  const [receivedEmail, setReceivedEmail] = useState<string>(
    `Hi Sarah,\n\nFollowing up on our product demo last week. We were impressed with MailCraft's AI capability. Could you share the enterprise pricing tier details and security compliance documentation so our procurement team can review?\n\nBest regards,\nMarcus Vance`
  );
  const [userNotes, setUserNotes] = useState<string>('Attach pricing link and confirm SOC2 compliance.');
  const [loading, setLoading] = useState<boolean>(false);
  const [replies, setReplies] = useState<ReplyAssistantOutput | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleGenerateReplies = async () => {
    if (!receivedEmail.trim()) {
      onShowToast('Please paste the received email text.');
      return;
    }

    setLoading(true);
    setCopiedKey(null);

    try {
      const res = await fetch('/api/ai/reply-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receivedEmail, userNotes }),
      });

      const data = await res.json();
      if (res.ok && data.replies) {
        setReplies(data.replies);
        onShowToast('Generated 4 reply options!');
      } else {
        onShowToast('Failed to generate replies');
      }
    } catch (err) {
      onShowToast('Error connecting to reply assistant server.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyOption = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    onShowToast(`Copied ${key} reply to clipboard!`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <Reply className="w-7 h-7 text-purple-400" /> AI Email Reply Assistant
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Paste any received email to generate 4 tailor-made response options (Professional, Friendly, Formal, Short).
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs */}
        <div className="lg:col-span-5 space-y-5 bg-slate-900/80 p-6 rounded-2xl border border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Received Email Text *
            </label>
            <textarea
              rows={8}
              value={receivedEmail}
              onChange={(e) => setReceivedEmail(e.target.value)}
              placeholder="Paste the email you received here..."
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-purple-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Key Notes / Instructions for your response (Optional)
            </label>
            <input
              type="text"
              value={userNotes}
              onChange={(e) => setUserNotes(e.target.value)}
              placeholder="e.g. Confirm Thursday meeting at 2 PM"
              className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-purple-500 focus:outline-none"
            />
          </div>

          <button
            onClick={handleGenerateReplies}
            disabled={loading}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-purple-600/25 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              'Analyzing & Generating Replies...'
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> Generate 4 Reply Options
              </>
            )}
          </button>
        </div>

        {/* Right Output Grid */}
        <div className="lg:col-span-7 space-y-4">
          <h3 className="text-sm font-bold text-white">Generated Reply Options</h3>

          {replies ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { key: 'professional', label: 'Professional Reply', badge: 'Recommended', color: 'border-indigo-500/30' },
                { key: 'friendly', label: 'Friendly & Warm', badge: 'Casual', color: 'border-purple-500/30' },
                { key: 'formal', label: 'Formal Executive', badge: 'Executive', color: 'border-pink-500/30' },
                { key: 'short', label: 'Quick / Short', badge: 'Brief', color: 'border-emerald-500/30' },
              ].map((opt) => {
                const content = replies[opt.key as keyof ReplyAssistantOutput];
                return (
                  <div
                    key={opt.key}
                    className={`p-5 rounded-2xl bg-slate-900/90 border ${opt.color} flex flex-col justify-between space-y-3`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-white">{opt.label}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                          {opt.badge}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                        {content}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/60 flex justify-end">
                      <button
                        onClick={() => handleCopyOption(opt.label, content)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-200 text-xs font-medium border border-slate-800 transition-colors"
                      >
                        {copiedKey === opt.label ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-purple-400" />
                        )}
                        {copiedKey === opt.label ? 'Copied' : 'Copy'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mx-auto">
                <Reply className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white">No Replies Generated Yet</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Paste an incoming email on the left to instantly produce 4 tailored reply variations.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
