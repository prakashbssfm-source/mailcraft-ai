import React, { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import {
  BookmarkCheck,
  Search,
  Star,
  Trash2,
  Copy,
  Download,
  Check,
  Filter,
  FileText,
} from 'lucide-react';
import { SavedEmail } from '../types/index.js';

interface SavedEmailsViewProps {
  onShowToast: (msg: string) => void;
}

export const SavedEmailsView: React.FC<SavedEmailsViewProps> = ({ onShowToast }) => {
  const [savedEmails, setSavedEmails] = useState<SavedEmail[]>([]);
  const [search, setSearch] = useState<string>('');
  const [onlyFavorites, setOnlyFavorites] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchSaved = () => {
    fetch('/api/saved-emails')
      .then((res) => res.json())
      .then((data) => {
        if (data.savedEmails) setSavedEmails(data.savedEmails);
      })
      .catch((err) => console.error(err));
  };

  useEffect(() => {
    fetchSaved();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/saved-emails/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setSavedEmails((prev) => prev.filter((e) => e.id !== id));
        onShowToast('Saved email removed.');
      }
    } catch (err) {
      onShowToast('Error deleting email.');
    }
  };

  const handleToggleFav = async (id: string) => {
    try {
      const res = await fetch(`/api/saved-emails/${id}/favorite`, { method: 'POST' });
      if (res.ok) {
        setSavedEmails((prev) =>
          prev.map((e) => (e.id === id ? { ...e, isFavorite: !e.isFavorite } : e))
        );
        onShowToast('Updated favorites!');
      }
    } catch (err) {
      onShowToast('Error updating favorite.');
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast('Copied email to clipboard!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadPDF = (email: SavedEmail) => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('MailCraft AI Saved Document', 14, 20);

    doc.setFontSize(12);
    doc.text(`Subject: ${email.subject}`, 14, 32);

    doc.setFontSize(10);
    const splitBody = doc.splitTextToSize(email.fullContent, 180);
    doc.text(splitBody, 14, 44);

    doc.save(`${email.title.replace(/[^a-z0-9]/gi, '_')}.pdf`);
    onShowToast('Downloaded PDF!');
  };

  const filtered = savedEmails.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.subject.toLowerCase().includes(search.toLowerCase()) ||
      item.body.toLowerCase().includes(search.toLowerCase());
    const matchesFav = !onlyFavorites || item.isFavorite;
    return matchesSearch && matchesFav;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <BookmarkCheck className="w-7 h-7 text-purple-400" /> Saved Email Library
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Manage your saved drafts, proposals, and frequently sent communications in one place.
        </p>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative max-w-md w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved emails..."
            className="w-full pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:border-purple-500 focus:outline-none"
          />
        </div>

        <button
          onClick={() => setOnlyFavorites(!onlyFavorites)}
          className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold border transition-colors ${
            onlyFavorites
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${onlyFavorites ? 'fill-amber-400' : ''}`} />
          Favorites Only
        </button>
      </div>

      {/* Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    {item.category}
                  </span>
                  <button
                    onClick={() => handleToggleFav(item.id)}
                    className="text-slate-500 hover:text-amber-400 p-1"
                  >
                    <Star
                      className={`w-4 h-4 ${
                        item.isFavorite ? 'text-amber-400 fill-amber-400' : ''
                      }`}
                    />
                  </button>
                </div>

                <h3 className="text-sm font-bold text-white">{item.title}</h3>
                <p className="text-xs font-semibold text-indigo-400 mt-1">Subject: {item.subject}</p>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 mt-3 whitespace-pre-line leading-relaxed max-h-36 overflow-y-auto">
                  {item.body}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[10px] text-slate-500">
                  Saved on {new Date(item.createdAt).toLocaleDateString()}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(item.id, item.fullContent)}
                    className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white text-xs"
                    title="Copy full content"
                  >
                    {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={() => handleDownloadPDF(item)}
                    className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white text-xs"
                    title="Download PDF"
                  >
                    <Download className="w-3.5 h-3.5 text-purple-400" />
                  </button>

                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-rose-400 text-xs"
                    title="Delete saved item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3">
          <BookmarkCheck className="w-8 h-8 text-slate-600 mx-auto" />
          <h4 className="text-sm font-bold text-white">No Saved Emails Found</h4>
          <p className="text-xs text-slate-400">Save generated emails to build your personal library.</p>
        </div>
      )}
    </div>
  );
};
