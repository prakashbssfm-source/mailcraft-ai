import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Zap,
  CheckCircle2,
  Shield,
  Clock,
  ArrowRight,
  ChevronDown,
  Star,
  Copy,
  Wand2,
  Lock,
  Globe2,
  Layers,
  BarChart3,
  Check,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (view: string) => void;
  onShowToast: (msg: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onShowToast }) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [demoTone, setDemoTone] = useState<string>('Professional');
  const [demoCategory, setDemoCategory] = useState<string>('Business Proposal');
  const [copiedDemo, setCopiedDemo] = useState<boolean>(false);

  const demoOutput = {
    subject: `Strategic Collaboration Proposal for Q3 2026`,
    body: `Dear Leadership Team,\n\nI hope this message finds you well. I am reaching out to propose a high-impact co-marketing initiative that aligns our respective software capabilities to accelerate customer onboarding.\n\nOur recent integration trials demonstrated a 45% reduction in client setup times. We would welcome a brief 15-minute call this Thursday to share the roadmap.`,
    closing: `Warm regards,`,
    signature: `Alex Morgan\nMailCraft Growth Lead`,
  };

  const handleCopyDemo = () => {
    navigator.clipboard.writeText(
      `Subject: ${demoOutput.subject}\n\n${demoOutput.body}\n\n${demoOutput.closing}\n${demoOutput.signature}`
    );
    setCopiedDemo(true);
    onShowToast('Copied demo email to clipboard!');
    setTimeout(() => setCopiedDemo(false), 2000);
  };

  const faqs = [
    {
      q: 'How does MailCraft generate personalized emails?',
      a: 'MailCraft leverages Google Gemini AI models to analyze your target category, recipient context, purpose, tone, and language to construct human-grade executive emails in seconds.',
    },
    {
      q: 'Can I generate emails in languages other than English?',
      a: 'Yes! MailCraft natively supports English, Spanish, French, German, Hindi, Marathi, and multiple other global languages with accurate idiom handling.',
    },
    {
      q: 'Is there a free tier available?',
      a: 'Absolutely. Every new user gets 10 free AI email credits per month with full access to basic templates and export tools.',
    },
    {
      q: 'Can I save and export generated emails?',
      a: 'Yes, you can save emails to your private cloud library, organize them with tags, and export them directly as formatted PDF documents or copy them in one click.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 overflow-x-hidden">
      {/* Background Decorative Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-indigo-600/15 via-purple-600/10 to-transparent blur-[120px] pointer-events-none -z-10" />

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-6"
        >
          <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
          Powered by Gemini 3.6 AI Models
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.1]"
        >
          Craft Perfect Emails in <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">Seconds.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-6 text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto font-normal leading-relaxed"
        >
          Generate professional emails, replies, improvements, and subject lines in any tone within seconds. Boost response rates with AI precision.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button
            onClick={() => onNavigate('signup')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 hover:scale-105 transition-all flex items-center justify-center gap-2"
          >
            Start Free <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigate('generate')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold text-sm transition-all flex items-center justify-center gap-2"
          >
            <Wand2 className="w-4 h-4 text-purple-400" />
            Try Interactive Generator
          </button>
        </motion.div>

        {/* Feature Highlights Pills */}
        <div className="mt-12 flex flex-wrap justify-center gap-6 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> No credit card required
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> 10 Free AI credits included
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> 15+ Email categories
          </div>
        </div>

        {/* Interactive Demo Graphic Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-14 max-w-4xl mx-auto rounded-2xl border border-slate-800/80 bg-slate-900/60 backdrop-blur-2xl p-6 shadow-2xl text-left text-sm"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-500/80" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="ml-2 text-xs text-slate-400 font-mono">MailCraft Studio Preview</span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={demoCategory}
                onChange={(e) => setDemoCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg text-xs px-2.5 py-1 text-slate-300 focus:outline-none"
              >
                <option>Business Proposal</option>
                <option>Job Application</option>
                <option>Meeting Request</option>
                <option>Cold Email</option>
              </select>

              <select
                value={demoTone}
                onChange={(e) => setDemoTone(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg text-xs px-2.5 py-1 text-slate-300 focus:outline-none"
              >
                <option>Professional</option>
                <option>Formal</option>
                <option>Persuasive</option>
                <option>Friendly</option>
              </select>
            </div>
          </div>

          <div className="space-y-3 bg-slate-950/80 rounded-xl p-5 border border-slate-800/50">
            <div className="text-xs text-slate-400">
              <span className="font-semibold text-indigo-400">Subject:</span> {demoOutput.subject}
            </div>
            <div className="text-slate-300 whitespace-pre-line leading-relaxed text-xs sm:text-sm">
              {demoOutput.body}
            </div>
            <div className="text-slate-400 text-xs font-medium pt-2 border-t border-slate-900">
              {demoOutput.closing}
              <br />
              <span className="text-slate-300 font-semibold">{demoOutput.signature}</span>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <span className="text-xs text-slate-500">Tone: <span className="text-indigo-400 font-medium">{demoTone}</span> • Category: <span className="text-purple-400 font-medium">{demoCategory}</span></span>
            <button
              onClick={handleCopyDemo}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
            >
              {copiedDemo ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedDemo ? 'Copied' : 'Copy Email'}
            </button>
          </div>
        </motion.div>
      </section>

      {/* Trusted Companies */}
      <section className="py-10 border-y border-slate-900 bg-slate-950/50">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs font-semibold tracking-wider text-slate-500 uppercase mb-6">
            Trusted by 25,000+ professionals from top tech teams
          </p>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all text-slate-400 text-sm font-semibold tracking-wide">
            <span>GOOGLE</span>
            <span>STRIPE</span>
            <span>NOTION</span>
            <span>VERCEL</span>
            <span>SHOPIFY</span>
            <span>AIRBNB</span>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Everything You Need to Master Email Communication
          </h2>
          <p className="mt-4 text-slate-400 text-sm">
            Four powerful AI engines combined into a single executive dashboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Sparkles,
              color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
              title: 'AI Email Generator',
              desc: 'Select category, tone, recipient, and key points. AI crafts tailor-made emails instantly.',
              action: 'generate',
            },
            {
              icon: Zap,
              color: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
              title: 'Smart Reply Assistant',
              desc: 'Paste received emails to generate 4 distinct reply variations (Professional, Friendly, Formal, Short).',
              action: 'reply',
            },
            {
              icon: Wand2,
              color: 'text-pink-400 bg-pink-500/10 border-pink-500/20',
              title: 'Email Draft Improver',
              desc: 'Elevate grammar, tone, clarity, and confidence with before/after quality metrics.',
              action: 'improve',
            },
            {
              icon: Layers,
              color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
              title: 'Subject Line Generator',
              desc: 'Generate 10 high-converting subject line variations with open-rate estimates.',
              action: 'subject',
            },
          ].map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                onClick={() => onNavigate(feature.action)}
                className="group p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${feature.color} mb-4`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">{feature.desc}</p>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-400">
                  Try now <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-slate-900/40 border-y border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-extrabold text-white">How MailCraft Works</h2>
            <p className="mt-3 text-slate-400 text-sm">3 simple steps to perfect email communication</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Choose Goal & Tone',
                desc: 'Select from 15+ email categories (Job application, proposal, payment reminder) and set your target tone and length.',
              },
              {
                step: '02',
                title: 'Enter Key Details',
                desc: 'Provide recipient name, company, and key points you wish to communicate.',
              },
              {
                step: '03',
                title: 'Generate & Export',
                desc: 'Gemini AI generates your complete email with subject, body, and signature. Copy or download as PDF.',
              },
            ].map((step, idx) => (
              <div key={idx} className="p-6 rounded-2xl bg-slate-950 border border-slate-800 relative">
                <span className="text-4xl font-extrabold text-indigo-500/20 font-mono block mb-3">
                  {step.step}
                </span>
                <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-extrabold text-white">Loved by Executives & Founders</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              quote: 'MailCraft saved our sales team over 15 hours a week crafting personalized enterprise cold outreach. Our response rate jumped 38%.',
              author: 'Elena Rostova',
              role: 'VP of Sales, CloudScale',
              stars: 5,
            },
            {
              quote: 'The Email Improver feature is like having an executive communications coach reviewing every draft before I hit send.',
              author: 'Marcus Vance',
              role: 'Founder & CEO, TechVentures',
              stars: 5,
            },
            {
              quote: 'Generating multi-tone reply variations in seconds has transformed how I manage my inbox backlog.',
              author: 'Dr. Priya Sharma',
              role: 'Director of Operations',
              stars: 5,
            },
          ].map((t, i) => (
            <div key={i} className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex gap-1 text-amber-400 mb-3">
                  {[...Array(t.stars)].map((_, s) => (
                    <Star key={s} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-slate-300 italic leading-relaxed mb-6">"{t.quote}"</p>
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">{t.author}</h4>
                <p className="text-[11px] text-slate-400">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-white">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="rounded-xl border border-slate-800 bg-slate-900/40 overflow-hidden">
              <button
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full text-left p-4 flex items-center justify-between text-sm font-semibold text-white"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${activeFaq === idx ? 'rotate-180' : ''}`} />
              </button>
              {activeFaq === idx && (
                <div className="px-4 pb-4 text-xs text-slate-400 leading-relaxed border-t border-slate-800/50 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-12 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-500 space-y-4">
          <p>© 2026 MailCraft AI SaaS. Craft Perfect Emails in Seconds.</p>
          <div className="flex justify-center gap-6">
            <button onClick={() => onNavigate('landing')} className="hover:text-slate-300">Privacy Policy</button>
            <button onClick={() => onNavigate('landing')} className="hover:text-slate-300">Terms of Service</button>
            <button onClick={() => onNavigate('pricing')} className="hover:text-slate-300">Pricing</button>
          </div>
        </div>
      </footer>
    </div>
  );
};
