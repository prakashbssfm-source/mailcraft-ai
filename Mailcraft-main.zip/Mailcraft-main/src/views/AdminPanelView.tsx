import React, { useState, useEffect } from 'react';
import { ShieldAlert, Users, DollarSign, Activity, FileText, Database, Check, AlertTriangle } from 'lucide-react';
import { AdminStats, UserProfile, SystemLog, EmailTemplate } from '../types/index.js';

interface AdminPanelViewProps {
  onShowToast: (msg: string) => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({ onShowToast }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'logs'>('overview');

  useEffect(() => {
    fetch('/api/admin/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data.stats) setStats(data.stats);
        if (data.users) setUsers(data.users);
        if (data.logs) setLogs(data.logs);
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <ShieldAlert className="w-7 h-7 text-emerald-400" /> Executive Admin Control Center
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Monitor real-time platform metrics, user growth, revenue MRR, system logs, and security alerts.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'overview'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          Analytics & System Overview
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'users'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          Manage Users ({users.length})
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'logs'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          System Health Logs ({logs.length})
        </button>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* KPI Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold block">Total Registered Users</span>
              <div className="text-2xl font-black text-white mt-1">{stats?.totalUsers || 1249}</div>
              <p className="text-[11px] text-emerald-400 mt-1">+{stats?.weeklyGrowth || 14}% this week</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold block">Active Users Today</span>
              <div className="text-2xl font-black text-white mt-1">{stats?.activeUsersToday || 342}</div>
              <p className="text-[11px] text-indigo-400 mt-1">Daily active engagement</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold block">Total Emails Generated</span>
              <div className="text-2xl font-black text-white mt-1">{stats?.totalEmailsGenerated || 18450}</div>
              <p className="text-[11px] text-purple-400 mt-1">Powered by Gemini AI</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold block">Monthly Recurring Revenue (MRR)</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">${stats?.mrr || 12840}</div>
              <p className="text-[11px] text-emerald-400 mt-1">{stats?.conversionRate || 8.4}% Pro Conversion</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-white">Gemini AI Model Infrastructure Health</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <p className="text-slate-400">Gemini 3.6 Flash Status</p>
                <p className="font-bold text-emerald-400 flex items-center gap-1">
                  <Check className="w-4 h-4" /> Operational (99.98% Uptime)
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <p className="text-slate-400">Average AI Latency</p>
                <p className="font-bold text-indigo-400">420ms Response Time</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <p className="text-slate-400">API Key Rate Limit</p>
                <p className="font-bold text-white">Auto-Inject Active</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase font-mono">
                <th className="pb-3">User</th>
                <th className="pb-3">Company & Role</th>
                <th className="pb-3">Plan</th>
                <th className="pb-3">Credits</th>
                <th className="pb-3">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-950/50">
                  <td className="py-3 font-semibold text-white">
                    {u.name}
                    <span className="block text-[11px] font-normal text-slate-400">{u.email}</span>
                  </td>
                  <td className="py-3 text-slate-300">
                    {u.company || 'Individual'} <span className="text-slate-500">({u.jobTitle || 'User'})</span>
                  </td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                        u.plan === 'Premium'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {u.plan}
                    </span>
                  </td>
                  <td className="py-3 font-mono text-indigo-400">{u.creditsRemaining}</td>
                  <td className="py-3 text-slate-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'logs' && (
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          {logs.map((log) => (
            <div
              key={log.id}
              className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs flex items-center justify-between gap-3"
            >
              <div className="space-y-0.5">
                <span className="font-mono text-[10px] text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <p className="text-slate-200">{log.message}</p>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-indigo-400">
                {log.user || 'System'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
