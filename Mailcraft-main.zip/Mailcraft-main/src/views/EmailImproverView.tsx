import React, { useState } from 'react';
import { Wand2, Copy, Check, ArrowRight, ShieldCheck, TrendingUp, HelpCircle } from 'lucide-react';
import { EmailImprovementOutput } from '../types/index.js';

interface EmailImproverViewProps {
  onShowToast: (msg: string) => void;
}

export const EmailImproverView: React.FC<EmailImproverViewProps> = ({ onShowToast }) => {
  const [draftText, setDraftText] = useState<string>(
    `hey john,\n\nim writing to ask if you had a chance to look at the budget proposal I sent last tuesday? thanks a lot and sorry to bother you if you are busy.`
  );

  const [options, setOptions] = useState({
    improveGrammar: true,
    improveSpelling: true,
    improveTone: true,
    improveProfessionalism: true,
    improveConfidence: true,
    improveClarity: true,
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<EmailImprovementOutput | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleImprove = async () => {
    if (!draftText.trim()) {
      onShowToast('Please paste a draft email to improve.');
      return;
    }

    setLoading(true);
    setCopied(false);

    try {
      const res = await fetch('/api/ai/improve-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ draftText, options }),
      });

      const data = await res.json();
      if (res.ok && data.result) {
        setResult(data.result);
        onShowToast('Draft improved successfully!');
      } else {
        onShowToast('Failed to improve draft.');
      }
    } catch (err) {
      onShowToast('Error connecting to improver server.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.improvedText);
    setCopied(true);
    onShowToast('Copied improved draft to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-2">
          <Wand2 className="w-7 h-7 text-pink-400" /> Smart Email Draft Improver
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Polish your rough draft into a clear, executive-level message. Correct grammar, boost tone, and eliminate passive language.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs */}
        <div className="lg:col-span-5 space-y-5 bg-slate-900/80 p-6 rounded-2xl border border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Your Rough Email Draft *
            </label>
            <textarea
              rows={8}
              value={draftText}
              onChange={(e) => setDraftText(e.target.value)}
              placeholder="Paste your rough draft here..."
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:border-pink-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">
              Target Improvements
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
              {Object.entries({
                improveGrammar: 'Grammar',
                improveSpelling: 'Spelling',
                improveTone: 'Tone Elevation',
                improveProfessionalism: 'Professionalism',
                improveConfidence: 'Confidence',
                improveClarity: 'Clarity & Conciseness',
              }).map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={options[key as keyof typeof options]}
                    onChange={(e) =>
                      setOptions({ ...options, [key]: e.target.checked })
                    }
                    className="rounded bg-slate-900 border-slate-700 text-pink-500 focus:ring-0"
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>
          </div>

          <button
            onClick={handleImprove}
            disabled={loading}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-pink-600/25 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              'Elevating Draft Quality...'
            ) : (
              <>
                <Wand2 className="w-4 h-4" /> Improve Draft
              </>
            )}
          </button>
        </div>

        {/* Right Output & Quality Metrics */}
        <div className="lg:col-span-7 space-y-6">
          {result ? (
            <div className="space-y-6">
              {/* Score Metric Header */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between flex-wrap gap-4">
                <div>
                  <span className="text-xs text-slate-400 block mb-0.5">Communication Quality Score</span>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-black text-rose-400 line-through opacity-70">
                      {result.scoreBefore}/100
                    </span>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                    <span className="text-3xl font-black text-emerald-400 flex items-center gap-1">
                      {result.scoreAfter}/100 <TrendingUp className="w-5 h-5 text-emerald-400" />
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Tone Shift</span>
                  <p className="text-xs font-semibold text-indigo-300">
                    {result.toneAnalysis.before} → <span className="text-emerald-400">{result.toneAnalysis.after}</span>
                  </p>
                </div>
              </div>

              {/* Improved Output Draft */}
              <div className="p-6 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-400">Polished Draft</span>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy Improved Draft'}
                  </button>
                </div>

                {result.improvedSubject && (
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                    <span className="text-slate-500 font-semibold">Recommended Subject: </span>
                    <span className="font-bold text-white">{result.improvedSubject}</span>
                  </div>
                )}

                <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 text-xs text-slate-200 whitespace-pre-line leading-relaxed">
                  {result.improvedText}
                </div>
              </div>

              {/* Specific Suggestions List */}
              {result.suggestions && result.suggestions.length > 0 && (
                <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-white">Specific AI Refinements Made</h4>
                  <div className="space-y-2">
                    {result.suggestions.map((s, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-purple-400">{s.category}</span>
                        </div>
                        <p className="text-slate-400 line-through text-[11px]">{s.originalText}</p>
                        <p className="text-emerald-400 font-medium">{s.suggestedText}</p>
                        <p className="text-[10px] text-slate-500 italic mt-0.5">{s.reasoning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-400 mx-auto">
                <Wand2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white">Ready to Improve Your Draft</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Enter your draft on the left and click "Improve Draft" to review AI recommendations and score analysis.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
