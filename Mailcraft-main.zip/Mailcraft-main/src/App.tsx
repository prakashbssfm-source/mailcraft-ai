import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { Navbar } from './components/layout/Navbar.js';
import { Sidebar } from './components/layout/Sidebar.js';
import { Toast } from './components/common/Toast.js';

import { LandingPage } from './views/LandingPage.js';
import { AuthPage } from './views/AuthPage.js';
import { DashboardView } from './views/DashboardView.js';
import { EmailGeneratorView } from './views/EmailGeneratorView.js';
import { ReplyAssistantView } from './views/ReplyAssistantView.js';
import { EmailImproverView } from './views/EmailImproverView.js';
import { SubjectGeneratorView } from './views/SubjectGeneratorView.js';
import { TemplatesView } from './views/TemplatesView.js';
import { SavedEmailsView } from './views/SavedEmailsView.js';
import { HistoryView } from './views/HistoryView.js';
import { ProfileView } from './views/ProfileView.js';
import { SettingsView } from './views/SettingsView.js';
import { PricingView } from './views/PricingView.js';
import { AdminPanelView } from './views/AdminPanelView.js';
import { EmailTemplate } from './types/index.js';

const MainContent: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [currentView, setCurrentView] = useState<string>('landing');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [prefillTemplate, setPrefillTemplate] = useState<{
    subject: string;
    body: string;
    category?: string;
  } | undefined>(undefined);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUseTemplate = (template: EmailTemplate) => {
    setPrefillTemplate({
      subject: template.defaultSubject,
      body: template.defaultBody,
      category: template.category,
    });
    handleNavigate('generate');
    showToast(`Loaded template "${template.title}" into AI Generator`);
  };

  const handleLogout = () => {
    logout();
    showToast('Signed out of MailCraft.');
    handleNavigate('landing');
  };

  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return (
          <LandingPage
            onGetStarted={() => {
              if (isAuthenticated) {
                handleNavigate('dashboard');
              } else {
                setAuthMode('signup');
                handleNavigate('auth');
              }
            }}
            onLogin={() => {
              setAuthMode('login');
              handleNavigate('auth');
            }}
          />
        );

      case 'auth':
        return (
          <AuthPage
            initialMode={authMode}
            onNavigate={handleNavigate}
            onShowToast={showToast}
          />
        );

      case 'dashboard':
        return <DashboardView onNavigate={handleNavigate} />;

      case 'generate':
        return (
          <EmailGeneratorView
            onShowToast={showToast}
            prefillTemplate={prefillTemplate}
          />
        );

      case 'reply':
        return <ReplyAssistantView onShowToast={showToast} />;

      case 'improve':
        return <EmailImproverView onShowToast={showToast} />;

      case 'subject':
        return <SubjectGeneratorView onShowToast={showToast} />;

      case 'templates':
        return (
          <TemplatesView
            onUseTemplate={handleUseTemplate}
            onShowToast={showToast}
          />
        );

      case 'saved':
        return <SavedEmailsView onShowToast={showToast} />;

      case 'history':
        return <HistoryView onShowToast={showToast} />;

      case 'profile':
        return <ProfileView onShowToast={showToast} onNavigate={handleNavigate} />;

      case 'settings':
        return <SettingsView onShowToast={showToast} />;

      case 'pricing':
        return <PricingView onShowToast={showToast} onNavigate={handleNavigate} />;

      case 'admin':
        return <AdminPanelView onShowToast={showToast} />;

      default:
        return <DashboardView onNavigate={handleNavigate} />;
    }
  };

  const isAppView =
    isAuthenticated &&
    currentView !== 'landing' &&
    currentView !== 'auth';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      <Navbar
        onNavigate={handleNavigate}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        currentView={currentView}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex overflow-hidden">
        {isAppView && (
          <Sidebar
            currentView={currentView}
            onNavigate={handleNavigate}
            isOpen={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
          />
        )}

        <main className="flex-1 overflow-y-auto">
          {renderView()}
        </main>
      </div>

      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
};

export function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <MainContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
