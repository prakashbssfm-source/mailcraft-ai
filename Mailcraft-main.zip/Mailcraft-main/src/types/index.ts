export type EmailCategory =
  | 'Job Application'
  | 'Leave Request'
  | 'Business Proposal'
  | 'Complaint'
  | 'Payment Reminder'
  | 'Meeting Request'
  | 'Follow-up'
  | 'Thank You'
  | 'Resignation'
  | 'Customer Support'
  | 'Scholarship Request'
  | 'Internship Request'
  | 'Recommendation Request'
  | 'Cold Email'
  | 'Sales Pitch'
  | 'Promotion'
  | 'Custom';

export type Language =
  | 'English'
  | 'Hindi'
  | 'Marathi'
  | 'Spanish'
  | 'French'
  | 'German';

export type Tone =
  | 'Professional'
  | 'Formal'
  | 'Friendly'
  | 'Persuasive'
  | 'Confident'
  | 'Empathetic'
  | 'Apologetic'
  | 'Short';

export type EmailLength = 'Short' | 'Medium' | 'Long';

export interface EmailGeneratorInput {
  category: EmailCategory;
  recipientName: string;
  companyName: string;
  purpose: string;
  keyPoints: string;
  additionalInstructions?: string;
  language: Language;
  tone: Tone;
  length: EmailLength;
  senderName?: string;
  senderTitle?: string;
}

export interface GeneratedEmailOutput {
  id: string;
  subject: string;
  body: string;
  closing: string;
  signature: string;
  fullContent: string;
  category: EmailCategory;
  tone: Tone;
  language: Language;
  createdAt: string;
}

export interface SavedEmail {
  id: string;
  userId: string;
  title: string;
  subject: string;
  body: string;
  closing: string;
  signature: string;
  fullContent: string;
  category: EmailCategory;
  tone: Tone;
  language: Language;
  isFavorite: boolean;
  createdAt: string;
  tags?: string[];
}

export interface EmailHistoryItem {
  id: string;
  userId: string;
  type: 'generator' | 'reply' | 'improver' | 'subject';
  subject: string;
  preview: string;
  fullContent: string;
  category: string;
  tone: string;
  createdAt: string;
}

export type TemplateCategory =
  | 'HR'
  | 'Sales'
  | 'Business'
  | 'Marketing'
  | 'Support'
  | 'Freelancing'
  | 'Students'
  | 'Internship'
  | 'Office'
  | 'Management'
  | 'Job Applications';

export interface EmailTemplate {
  id: string;
  title: string;
  description: string;
  category: TemplateCategory;
  defaultSubject: string;
  defaultBody: string;
  placeholders: string[];
  usesCount: number;
  isPopular?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  company?: string;
  jobTitle?: string;
  role: 'user' | 'admin';
  plan: 'Free' | 'Premium';
  creditsRemaining: number;
  maxCredits: number;
  createdAt: string;
}

export interface ReplyAssistantOutput {
  professional: string;
  friendly: string;
  formal: string;
  short: string;
}

export interface ImprovementSuggestion {
  category: 'Grammar' | 'Spelling' | 'Tone' | 'Clarity' | 'Professionalism' | 'Confidence';
  originalText: string;
  suggestedText: string;
  reasoning: string;
}

export interface EmailImprovementOutput {
  originalText: string;
  improvedText: string;
  improvedSubject?: string;
  scoreBefore: number;
  scoreAfter: number;
  suggestions: ImprovementSuggestion[];
  toneAnalysis: {
    before: string;
    after: string;
  };
}

export interface SubjectLineVariant {
  id: string;
  subject: string;
  tone: string;
  estimatedOpenRate: number; // e.g. 88%
}

export interface WeeklyUsageData {
  day: string;
  emailsGenerated: number;
  templatesUsed: number;
}

export interface MonthlyUsageData {
  month: string;
  emailsGenerated: number;
  savedEmails: number;
}

export interface AdminStats {
  totalUsers: number;
  activeUsersToday: number;
  totalEmailsGenerated: number;
  mrr: number;
  conversionRate: number;
  weeklyGrowth: number;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error';
  message: string;
  user?: string;
}
