import {
  UserProfile,
  SavedEmail,
  EmailHistoryItem,
  EmailTemplate,
  WeeklyUsageData,
  MonthlyUsageData,
  AdminStats,
  SystemLog,
} from '../src/types/index.js';

// Seed initial templates
export const INITIAL_TEMPLATES: EmailTemplate[] = [
  {
    id: 'tmpl_1',
    title: 'Executive Job Application',
    description: 'A compelling cover email tailored for senior roles with key metrics.',
    category: 'Job Applications',
    defaultSubject: 'Application for [Job Title] Role - [Your Name]',
    defaultBody: 'Dear Hiring Manager,\n\nI am writing to express my enthusiastic interest in the [Job Title] position at [Company Name]. With over [Number] years of experience driving growth and leading cross-functional teams, I am confident in my ability to deliver immediate value.\n\nIn my previous role as [Current/Past Role], I successfully [Key Achievement/Metric].\n\nI welcome the opportunity to discuss how my skill set aligns with your team goals.',
    placeholders: ['Job Title', 'Your Name', 'Company Name', 'Number', 'Current/Past Role', 'Key Achievement/Metric'],
    usesCount: 1420,
    isPopular: true,
  },
  {
    id: 'tmpl_2',
    title: 'Urgent Payment Reminder',
    description: 'Polite yet firm payment reminder for outstanding invoices.',
    category: 'Sales',
    defaultSubject: 'Payment Reminder: Invoice #[Invoice Number] - Overdue',
    defaultBody: 'Dear [Client Name],\n\nI hope you are having a productive week.\n\nThis is a friendly reminder that Invoice #[Invoice Number] for [Project Name], totaling $[Amount], was due on [Due Date].\n\nPlease let me know if you need another copy of the invoice or assistance processing payment.',
    placeholders: ['Client Name', 'Invoice Number', 'Project Name', 'Amount', 'Due Date'],
    usesCount: 980,
    isPopular: true,
  },
  {
    id: 'tmpl_3',
    title: 'B2B Cold Outreach Pitch',
    description: 'High-converting cold email pitch for enterprise prospects.',
    category: 'Sales',
    defaultSubject: 'Streamlining [Prospect Company]\'s [Department] Workflows',
    defaultBody: 'Hi [Prospect First Name],\n\nI noticed [Prospect Company] recently [Recent Company Milestone/News]. Congrats!\n\nWe recently helped [Similar Company] reduce their email response cycles by 60% using our AI solution.\n\nWould you be open to a brief 10-minute call this Thursday at 2 PM EST to explore if we could do the same for your team?',
    placeholders: ['Prospect First Name', 'Prospect Company', 'Department', 'Recent Company Milestone/News', 'Similar Company'],
    usesCount: 2100,
    isPopular: true,
  },
  {
    id: 'tmpl_4',
    title: 'Leave Request (Medical/Personal)',
    description: 'Formal leave application for office management and HR approval.',
    category: 'Leave Request' as any,
    defaultSubject: 'Leave Application: [Your Name] - [Start Date] to [End Date]',
    defaultBody: 'Dear [Manager Name],\n\nI am writing to formally request leave from [Start Date] to [End Date] due to [Reason/Personal Matters].\n\nDuring my absence, [Colleague Name] has kindly agreed to cover my urgent responsibilities. I will remain reachable via email for critical emergencies.',
    placeholders: ['Manager Name', 'Your Name', 'Start Date', 'End Date', 'Reason/Personal Matters', 'Colleague Name'],
    usesCount: 850,
  },
  {
    id: 'tmpl_5',
    title: 'Strategic Business Proposal',
    description: 'Formal pitch for partnership or joint venture collaboration.',
    category: 'Business',
    defaultSubject: 'Partnership Proposal: [Your Company] & [Partner Company]',
    defaultBody: 'Dear [Partner Name],\n\nFollowing our recent discussion, I am excited to share a formal partnership proposal highlighting how [Your Company] and [Partner Company] can collaborate to capture market opportunity in [Industry/Sector].\n\nKey synergy areas include:\n1. [Synergy 1]\n2. [Synergy 2]\n\nI have attached the detailed proposal deck for your review.',
    placeholders: ['Partner Name', 'Your Company', 'Partner Company', 'Industry/Sector', 'Synergy 1', 'Synergy 2'],
    usesCount: 1150,
    isPopular: true,
  },
  {
    id: 'tmpl_6',
    title: 'Student Scholarship Request',
    description: 'Respectful scholarship inquiry for academic institution admissions.',
    category: 'Students',
    defaultSubject: 'Scholarship Inquiry: [Your Full Name] - [Program Name]',
    defaultBody: 'Dear Scholarship Committee,\n\nI am writing to express my strong interest in applying for the [Scholarship Name] for the upcoming [Academic Year] session in [Program Name].\n\nHaving maintained a GPA of [GPA] and led [Extracurricular Activity], this scholarship would enable me to focus entirely on my academic research.',
    placeholders: ['Your Full Name', 'Scholarship Name', 'Academic Year', 'Program Name', 'GPA', 'Extracurricular Activity'],
    usesCount: 640,
  },
  {
    id: 'tmpl_7',
    title: 'Freelance Project Quote Follow-Up',
    description: 'Gentle follow-up after submitting a freelance project estimate.',
    category: 'Freelancing',
    defaultSubject: 'Following Up: Proposal for [Project Name]',
    defaultBody: 'Hi [Client Name],\n\nI wanted to check in regarding the proposal I sent last week for [Project Name].\n\nDo you have any questions or adjustments you would like to discuss before we finalize the timeline and get started?',
    placeholders: ['Client Name', 'Project Name'],
    usesCount: 1320,
    isPopular: true,
  },
  {
    id: 'tmpl_8',
    title: 'Post-Interview Thank You',
    description: 'Polished thank-you note after a job interview to reinforce candidacy.',
    category: 'Job Applications',
    defaultSubject: 'Thank you for the opportunity - [Position Name] Interview',
    defaultBody: 'Dear [Interviewer Name],\n\nThank you for taking the time to speak with me today regarding the [Position Name] role. I really enjoyed learning more about [Company Name]\'s mission and the upcoming initiatives in [Department].\n\nOur conversation reinforced my enthusiasm for joining your team.',
    placeholders: ['Interviewer Name', 'Position Name', 'Company Name', 'Department'],
    usesCount: 1890,
    isPopular: true,
  },
];

// Seeded In-Memory State Store
class DatabaseStore {
  private users: UserProfile[] = [
    {
      id: 'usr_demo',
      name: 'Sarah Jenkins',
      email: 'sarah.jenkins@mailcraft.io',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      company: 'Acme Innovation',
      jobTitle: 'Head of Growth',
      role: 'admin',
      plan: 'Premium',
      creditsRemaining: 485,
      maxCredits: 500,
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    },
  ];

  private savedEmails: SavedEmail[] = [
    {
      id: 'saved_1',
      userId: 'usr_demo',
      title: 'Q3 Partnership Proposal to TechCorp',
      subject: 'Strategic Co-Marketing Proposal for Q3 2026',
      body: 'Dear TechCorp Leadership,\n\nI hope this email finds you well. I am reaching out from MailCraft to propose a joint marketing initiative aimed at enhancing customer onboarding for cloud teams.',
      closing: 'Best regards,',
      signature: 'Sarah Jenkins\nHead of Growth, MailCraft',
      fullContent: 'Subject: Strategic Co-Marketing Proposal for Q3 2026\n\nDear TechCorp Leadership,\n\nI hope this email finds you well. I am reaching out from MailCraft to propose a joint marketing initiative aimed at enhancing customer onboarding for cloud teams.\n\nBest regards,\nSarah Jenkins',
      category: 'Business Proposal',
      tone: 'Professional',
      language: 'English',
      isFavorite: true,
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
      tags: ['Partnership', 'Q3', 'Enterprise'],
    },
    {
      id: 'saved_2',
      userId: 'usr_demo',
      title: 'Follow up with Client regarding Invoice #8841',
      subject: 'Payment Reminder: Outstanding Invoice #8841',
      body: 'Hi Marcus,\n\nFriendly check-in regarding Invoice #8841 sent two weeks ago. Please let me know when payment is scheduled.',
      closing: 'Warmly,',
      signature: 'Sarah Jenkins',
      fullContent: 'Subject: Payment Reminder: Outstanding Invoice #8841\n\nHi Marcus,\n\nFriendly check-in regarding Invoice #8841 sent two weeks ago. Please let me know when payment is scheduled.\n\nWarmly,\nSarah Jenkins',
      category: 'Payment Reminder',
      tone: 'Friendly',
      language: 'English',
      isFavorite: false,
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      tags: ['Finance'],
    },
  ];

  private history: EmailHistoryItem[] = [
    {
      id: 'hist_1',
      userId: 'usr_demo',
      type: 'generator',
      subject: 'Strategic Co-Marketing Proposal for Q3 2026',
      preview: 'I hope this email finds you well. I am reaching out from MailCraft...',
      fullContent: 'Subject: Strategic Co-Marketing Proposal for Q3 2026\n\nDear TechCorp Leadership...',
      category: 'Business Proposal',
      tone: 'Professional',
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
    {
      id: 'hist_2',
      userId: 'usr_demo',
      type: 'reply',
      subject: 'Re: Project Alpha Launch Timeline',
      preview: 'Thank you for reaching out regarding the timeline. I agree with shifting...',
      fullContent: 'Thank you for reaching out regarding the timeline. I agree with shifting the launch to Friday.',
      category: 'Meeting Request',
      tone: 'Confident',
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    },
    {
      id: 'hist_3',
      userId: 'usr_demo',
      type: 'improver',
      subject: 'Updated Executive Communication Draft',
      preview: 'I am writing to formally request a review of our quarterly goals...',
      fullContent: 'I am writing to formally request a review of our quarterly goals for Q4.',
      category: 'Office',
      tone: 'Formal',
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    },
  ];

  private templates: EmailTemplate[] = [...INITIAL_TEMPLATES];

  private logs: SystemLog[] = [
    {
      id: 'log_1',
      timestamp: new Date().toISOString(),
      level: 'info',
      message: 'System booted successfully. Gemini AI integration active.',
      user: 'System',
    },
    {
      id: 'log_2',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      level: 'info',
      message: 'User sarah.jenkins@mailcraft.io logged in.',
      user: 'Sarah Jenkins',
    },
    {
      id: 'log_3',
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      level: 'info',
      message: 'Email generated: Business Proposal in English (Professional tone)',
      user: 'Sarah Jenkins',
    },
  ];

  public getUserById(id: string): UserProfile | undefined {
    return this.users.find((u) => u.id === id);
  }

  public getUserByEmail(email: string): UserProfile | undefined {
    return this.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(userData: Partial<UserProfile>): UserProfile {
    const newUser: UserProfile = {
      id: 'usr_' + Date.now(),
      name: userData.name || 'MailCraft User',
      email: userData.email || 'user@mailcraft.io',
      role: 'user',
      plan: 'Free',
      creditsRemaining: 10,
      maxCredits: 10,
      createdAt: new Date().toISOString(),
      company: userData.company || '',
      jobTitle: userData.jobTitle || '',
    };
    this.users.push(newUser);
    this.addLog('info', `New user signed up: ${newUser.email}`, newUser.name);
    return newUser;
  }

  public deductCredit(userId: string, amount: number = 1): boolean {
    const user = this.getUserById(userId);
    if (!user) return false;
    if (user.plan === 'Premium') return true; // Unlimited
    if (user.creditsRemaining >= amount) {
      user.creditsRemaining -= amount;
      return true;
    }
    return false;
  }

  public getSavedEmails(userId: string): SavedEmail[] {
    return this.savedEmails.filter((e) => e.userId === userId);
  }

  public addSavedEmail(email: SavedEmail): SavedEmail {
    this.savedEmails.unshift(email);
    return email;
  }

  public deleteSavedEmail(id: string): boolean {
    const idx = this.savedEmails.findIndex((e) => e.id === id);
    if (idx !== -1) {
      this.savedEmails.splice(idx, 1);
      return true;
    }
    return false;
  }

  public toggleFavoriteSavedEmail(id: string): SavedEmail | undefined {
    const item = this.savedEmails.find((e) => e.id === id);
    if (item) {
      item.isFavorite = !item.isFavorite;
    }
    return item;
  }

  public getHistory(userId: string): EmailHistoryItem[] {
    return this.history.filter((h) => h.userId === userId);
  }

  public addHistoryItem(item: EmailHistoryItem): EmailHistoryItem {
    this.history.unshift(item);
    return item;
  }

  public getTemplates(): EmailTemplate[] {
    return this.templates;
  }

  public addTemplate(template: EmailTemplate): EmailTemplate {
    this.templates.push(template);
    return template;
  }

  public incrementTemplateUses(templateId: string) {
    const tmpl = this.templates.find((t) => t.id === templateId);
    if (tmpl) {
      tmpl.usesCount += 1;
    }
  }

  public getWeeklyUsage(): WeeklyUsageData[] {
    return [
      { day: 'Mon', emailsGenerated: 12, templatesUsed: 4 },
      { day: 'Tue', emailsGenerated: 19, templatesUsed: 8 },
      { day: 'Wed', emailsGenerated: 25, templatesUsed: 11 },
      { day: 'Thu', emailsGenerated: 32, templatesUsed: 14 },
      { day: 'Fri', emailsGenerated: 28, templatesUsed: 9 },
      { day: 'Sat', emailsGenerated: 14, templatesUsed: 3 },
      { day: 'Sun', emailsGenerated: 18, templatesUsed: 5 },
    ];
  }

  public getMonthlyUsage(): MonthlyUsageData[] {
    return [
      { month: 'Jan', emailsGenerated: 140, savedEmails: 32 },
      { month: 'Feb', emailsGenerated: 210, savedEmails: 48 },
      { month: 'Mar', emailsGenerated: 310, savedEmails: 85 },
      { month: 'Apr', emailsGenerated: 420, savedEmails: 110 },
      { month: 'May', emailsGenerated: 590, savedEmails: 165 },
      { month: 'Jun', emailsGenerated: 780, savedEmails: 210 },
      { month: 'Jul', emailsGenerated: 940, savedEmails: 280 },
    ];
  }

  public getAdminStats(): AdminStats {
    return {
      totalUsers: this.users.length + 1248,
      activeUsersToday: 342,
      totalEmailsGenerated: 18450,
      mrr: 12840,
      conversionRate: 8.4,
      weeklyGrowth: 14.2,
    };
  }

  public getUsersList(): UserProfile[] {
    return this.users;
  }

  public getLogs(): SystemLog[] {
    return this.logs;
  }

  public addLog(level: 'info' | 'warn' | 'error', message: string, user?: string) {
    this.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      level,
      message,
      user,
    });
  }
}

export const db = new DatabaseStore();
