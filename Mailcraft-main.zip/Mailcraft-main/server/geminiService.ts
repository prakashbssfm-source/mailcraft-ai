import { GoogleGenAI } from '@google/genai';
import {
  EmailGeneratorInput,
  GeneratedEmailOutput,
  ReplyAssistantOutput,
  EmailImprovementOutput,
  SubjectLineVariant,
} from '../src/types/index.js';

// Initialize Gemini client with proper telemetry headers
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || 'demo_key',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const MODEL_NAME = 'gemini-3.6-flash';

/**
 * Generate a complete email based on detailed input options.
 */
export async function generateAIEmail(
  input: EmailGeneratorInput
): Promise<GeneratedEmailOutput> {
  const prompt = `You are MailCraft AI, an expert executive communication and copywriting assistant.
Generate a high-converting, polished email according to the following requirements:

Category: ${input.category}
Recipient Name: ${input.recipientName || 'Recipient'}
Company Name: ${input.companyName || 'Organization'}
Purpose/Goal: ${input.purpose}
Key Points to Include: ${input.keyPoints}
Additional Instructions: ${input.additionalInstructions || 'None'}
Language: ${input.language}
Tone: ${input.tone}
Length: ${input.length} (Short = ~2-3 sentences, Medium = ~2-3 paragraphs, Long = comprehensive)
Sender Name: ${input.senderName || 'Sender'}
Sender Title/Role: ${input.senderTitle || 'Professional'}

Output strictly valid JSON with the following key structure:
{
  "subject": "The email subject line",
  "body": "The main email body paragraphs (formatted with line breaks)",
  "closing": "Professional closing phrase (e.g., Warm regards, Best regards, Sincerely)",
  "signature": "Sender name and title line"
}`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);

      const subject = parsed.subject || `${input.category}: ${input.purpose.slice(0, 40)}`;
      const body = parsed.body || `Dear ${input.recipientName || 'Valued Partner'},\n\nI am writing regarding ${input.purpose}.\n\n${input.keyPoints}\n\nThank you for your time.`;
      const closing = parsed.closing || 'Best regards,';
      const signature = parsed.signature || (input.senderName ? `${input.senderName}\n${input.senderTitle || ''}` : 'MailCraft User');
      const fullContent = `Subject: ${subject}\n\n${body}\n\n${closing}\n${signature}`;

      return {
        id: 'email_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        subject,
        body,
        closing,
        signature,
        fullContent,
        category: input.category,
        tone: input.tone,
        language: input.language,
        createdAt: new Date().toISOString(),
      };
    }
  } catch (err) {
    console.warn('Gemini API call warning/fallback triggered:', err);
  }

  // Smart Fallback Generator if key is not configured or fails
  const mockSubject = `[${input.tone}] ${input.category}: ${input.purpose || 'Follow up'}`;
  const mockBody = `Dear ${input.recipientName || 'Team'},\n\nI hope this email finds you well.\n\nI am reaching out regarding ${input.purpose || 'our upcoming collaboration'}. ${input.keyPoints ? 'Specifically: ' + input.keyPoints + '.' : ''}\n\nLooking forward to hearing your thoughts and proceeding smoothly. Please let me know if you have any questions.\n\nThank you for your attention to this matter.`;
  const mockClosing = input.tone === 'Formal' ? 'Sincerely,' : input.tone === 'Friendly' ? 'Warmly,' : 'Best regards,';
  const mockSignature = `${input.senderName || 'Alex Morgan'}\n${input.senderTitle || 'MailCraft Member'}`;

  return {
    id: 'email_' + Date.now(),
    subject: mockSubject,
    body: mockBody,
    closing: mockClosing,
    signature: mockSignature,
    fullContent: `Subject: ${mockSubject}\n\n${mockBody}\n\n${mockClosing}\n${mockSignature}`,
    category: input.category,
    tone: input.tone,
    language: input.language,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Generate 4 distinct reply variants for a received email.
 */
export async function generateAIReply(
  receivedEmail: string,
  userNotes?: string
): Promise<ReplyAssistantOutput> {
  const prompt = `You are MailCraft AI Email Reply Assistant.
Analyze the following received email and generate 4 distinct reply variations:
1. Professional Reply
2. Friendly Reply
3. Formal Reply
4. Short / Quick Reply

Received Email:
"""
${receivedEmail}
"""

User Context/Notes for response (if any):
${userNotes || 'Acknowledge gracefully and respond constructively'}

Output strictly valid JSON:
{
  "professional": "The complete professional reply text",
  "friendly": "The complete friendly reply text",
  "formal": "The complete formal reply text",
  "short": "The complete short reply text"
}`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);
      if (parsed.professional && parsed.friendly && parsed.formal && parsed.short) {
        return parsed as ReplyAssistantOutput;
      }
    }
  } catch (err) {
    console.warn('Gemini API reply fallback:', err);
  }

  // Fallback responses
  return {
    professional: `Thank you for reaching out regarding this matter. I have reviewed the details and agree with the proposed direction. Let us connect on Thursday to finalize the next steps.\n\nBest regards,\nAlex Morgan`,
    friendly: `Hi there!\n\nThanks so much for sending this over! Everything looks super solid to me. I'd love to jump on a quick call this week whenever you're free to chat through the details.\n\nCheers,\nAlex`,
    formal: `Dear Sender,\n\nI acknowledge receipt of your email concerning this subject. The details provided have been reviewed thoroughly. Please consider this confirmation of our intention to proceed under the discussed terms.\n\nSincerely yours,\nAlex Morgan`,
    short: `Received with thanks! I agree with the proposal and will follow up shortly with additional details.\n\nBest,\nAlex`,
  };
}

/**
 * Analyze & Improve an existing email draft.
 */
export async function improveAIEmail(
  draftText: string,
  options: {
    improveGrammar: boolean;
    improveSpelling: boolean;
    improveTone: boolean;
    improveProfessionalism: boolean;
    improveConfidence: boolean;
    improveClarity: boolean;
  }
): Promise<EmailImprovementOutput> {
  const prompt = `You are MailCraft AI Email Improver & Grammar Expert.
Analyze and elevate the following draft email according to requested improvements:
- Grammar: ${options.improveGrammar}
- Spelling: ${options.improveSpelling}
- Tone Enhancement: ${options.improveTone}
- Professionalism: ${options.improveProfessionalism}
- Confidence Booster: ${options.improveConfidence}
- Clarity & Conciseness: ${options.improveClarity}

Draft Email:
"""
${draftText}
"""

Provide JSON output formatted as:
{
  "improvedText": "The fully enhanced, error-free, persuasive email draft",
  "improvedSubject": "A compelling recommended subject line",
  "scoreBefore": 62, // integer 0-100 rating draft quality
  "scoreAfter": 96,  // integer 0-100 rating improved quality
  "toneAnalysis": {
    "before": "Hesitant, informal, slightly disjointed",
    "after": "Confident, executive, clear, persuasive"
  },
  "suggestions": [
    {
      "category": "Grammar",
      "originalText": "phrase with error",
      "suggestedText": "corrected phrase",
      "reasoning": "Explanation of fix"
    },
    ...
  ]
}`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.6,
        },
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);
      return {
        originalText: draftText,
        improvedText: parsed.improvedText || draftText,
        improvedSubject: parsed.improvedSubject || 'Refined Communication',
        scoreBefore: parsed.scoreBefore || 65,
        scoreAfter: parsed.scoreAfter || 95,
        toneAnalysis: parsed.toneAnalysis || { before: 'Draft Quality', after: 'Executive Ready' },
        suggestions: parsed.suggestions || [],
      };
    }
  } catch (err) {
    console.warn('Gemini API improver fallback:', err);
  }

  // Fallback response
  return {
    originalText: draftText,
    improvedText: draftText
      .replace(/im writing/gi, "I am writing")
      .replace(/thanks/gi, "Thank you") +
      "\n\nI appreciate your prompt attention to this matter and look forward to your valuable feedback.",
    improvedSubject: "Follow-Up: Project Status & Key Next Steps",
    scoreBefore: 68,
    scoreAfter: 94,
    toneAnalysis: {
      before: "Informal and passive",
      after: "Polished, confident, and action-oriented",
    },
    suggestions: [
      {
        category: "Clarity",
        originalText: "I was wondering if maybe we could chat",
        suggestedText: "I would welcome the opportunity to discuss",
        reasoning: "Eliminates passive hedging language to project confidence.",
      },
      {
        category: "Professionalism",
        originalText: "thanks a lot",
        suggestedText: "Thank you for your guidance",
        reasoning: "Elevates tone to match modern executive communication standards.",
      },
    ],
  };
}

/**
 * Generate 10 high-converting subject line variations.
 */
export async function generateAISubjects(
  context: string,
  targetAudience?: string
): Promise<SubjectLineVariant[]> {
  const prompt = `You are a world-class email subject line strategist.
Generate 10 distinct, high-open-rate subject lines for the following topic:

Topic / Email Purpose: ${context}
Target Audience: ${targetAudience || 'General Business / Clients'}

Generate a mix of curiosity-driven, direct, urgent, friendly, and formal subject lines.

Return strictly valid JSON array of 10 objects:
[
  {
    "id": "1",
    "subject": "Subject line text",
    "tone": "Urgent / Curious / Direct / Friendly / Professional",
    "estimatedOpenRate": 92
  },
  ...
]`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.8,
        },
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item: any, index: number) => ({
          id: String(index + 1),
          subject: item.subject || `Subject Option ${index + 1}`,
          tone: item.tone || 'Professional',
          estimatedOpenRate: item.estimatedOpenRate || Math.floor(80 + Math.random() * 18),
        }));
      }
    }
  } catch (err) {
    console.warn('Gemini API subjects fallback:', err);
  }

  // Fallback 10 subject lines
  const cleanContext = context.slice(0, 30);
  return [
    { id: '1', subject: `Quick question regarding ${cleanContext}`, tone: 'Direct & Concise', estimatedOpenRate: 94 },
    { id: '2', subject: `Action Required: Important update on ${cleanContext}`, tone: 'Urgent', estimatedOpenRate: 91 },
    { id: '3', subject: `Following up on our conversation about ${cleanContext}`, tone: 'Professional', estimatedOpenRate: 89 },
    { id: '4', subject: `3 ideas to optimize ${cleanContext}`, tone: 'Value-driven', estimatedOpenRate: 88 },
    { id: '5', subject: `Hi! Thoughts on this for ${cleanContext}?`, tone: 'Friendly & Casual', estimatedOpenRate: 86 },
    { id: '6', subject: `Proposal & Next Steps for ${cleanContext}`, tone: 'Formal', estimatedOpenRate: 92 },
    { id: '7', subject: `Before you proceed with ${cleanContext}, read this`, tone: 'Curiosity', estimatedOpenRate: 90 },
    { id: '8', subject: `Meeting Request: ${cleanContext} Strategy`, tone: 'Actionable', estimatedOpenRate: 87 },
    { id: '9', subject: `Exclusive insight into ${cleanContext}`, tone: 'Persuasive', estimatedOpenRate: 85 },
    { id: '10', subject: `Thank you for your time - Quick recap on ${cleanContext}`, tone: 'Appreciative', estimatedOpenRate: 93 },
  ];
}
