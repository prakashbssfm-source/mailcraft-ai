import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db.js';
import {
  generateAIEmail,
  generateAIReply,
  improveAIEmail,
  generateAISubjects,
} from './server/geminiService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'MailCraft AI SaaS', timestamp: new Date().toISOString() });
  });

  // Auth Endpoints
  app.post('/api/auth/login', (req, res) => {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    let user = db.getUserByEmail(email);
    if (!user) {
      user = db.createUser({ email, name: email.split('@')[0] });
    }
    res.json({ token: 'jwt_mock_token_' + user.id, user });
  });

  app.post('/api/auth/register', (req, res) => {
    const { name, email, company, jobTitle } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    const existing = db.getUserByEmail(email);
    if (existing) {
      return res.json({ token: 'jwt_mock_token_' + existing.id, user: existing });
    }
    const user = db.createUser({ name, email, company, jobTitle });
    res.json({ token: 'jwt_mock_token_' + user.id, user });
  });

  app.get('/api/auth/me', (req, res) => {
    const authHeader = req.headers.authorization;
    const defaultUser = db.getUserById('usr_demo');
    if (!authHeader) {
      return res.json({ user: defaultUser });
    }
    const userId = authHeader.replace('Bearer jwt_mock_token_', '');
    const user = db.getUserById(userId) || defaultUser;
    res.json({ user });
  });

  // AI Email Generator
  app.post('/api/ai/generate-email', async (req, res) => {
    try {
      const input = req.body;
      const userId = req.body.userId || 'usr_demo';

      // Deduct credit check
      const creditGranted = db.deductCredit(userId, 1);
      if (!creditGranted) {
        return res.status(402).json({
          error: 'AI Credit limit reached. Please upgrade to MailCraft Premium for unlimited emails.',
        });
      }

      const generated = await generateAIEmail(input);

      // Save to history
      db.addHistoryItem({
        id: 'hist_' + Date.now(),
        userId,
        type: 'generator',
        subject: generated.subject,
        preview: generated.body.slice(0, 100) + '...',
        fullContent: generated.fullContent,
        category: generated.category,
        tone: generated.tone,
        createdAt: generated.createdAt,
      });

      db.addLog('info', `Generated email (${generated.category} - ${generated.tone})`, userId);

      res.json({ email: generated, user: db.getUserById(userId) });
    } catch (error: any) {
      console.error('Email generation error:', error);
      res.status(500).json({ error: error.message || 'Failed to generate email' });
    }
  });

  // AI Reply Assistant
  app.post('/api/ai/reply-email', async (req, res) => {
    try {
      const { receivedEmail, userNotes, userId = 'usr_demo' } = req.body;
      if (!receivedEmail) {
        return res.status(400).json({ error: 'Received email text is required' });
      }

      const replies = await generateAIReply(receivedEmail, userNotes);

      // Record in history
      db.addHistoryItem({
        id: 'hist_' + Date.now(),
        userId,
        type: 'reply',
        subject: 'Re: ' + (receivedEmail.split('\n')[0]?.slice(0, 40) || 'Received Message'),
        preview: replies.professional.slice(0, 100) + '...',
        fullContent: replies.professional,
        category: 'Reply Assistant',
        tone: 'Varied',
        createdAt: new Date().toISOString(),
      });

      res.json({ replies });
    } catch (error: any) {
      console.error('Reply generator error:', error);
      res.status(500).json({ error: 'Failed to generate email replies' });
    }
  });

  // AI Email Improver
  app.post('/api/ai/improve-email', async (req, res) => {
    try {
      const { draftText, options, userId = 'usr_demo' } = req.body;
      if (!draftText) {
        return res.status(400).json({ error: 'Draft text is required' });
      }

      const result = await improveAIEmail(draftText, options || {
        improveGrammar: true,
        improveSpelling: true,
        improveTone: true,
        improveProfessionalism: true,
        improveConfidence: true,
        improveClarity: true,
      });

      db.addHistoryItem({
        id: 'hist_' + Date.now(),
        userId,
        type: 'improver',
        subject: result.improvedSubject || 'Polished Draft',
        preview: result.improvedText.slice(0, 100) + '...',
        fullContent: result.improvedText,
        category: 'Email Improver',
        tone: result.toneAnalysis.after,
        createdAt: new Date().toISOString(),
      });

      res.json({ result });
    } catch (error: any) {
      console.error('Email improver error:', error);
      res.status(500).json({ error: 'Failed to improve email' });
    }
  });

  // Smart Subject Line Generator
  app.post('/api/ai/generate-subjects', async (req, res) => {
    try {
      const { context, targetAudience } = req.body;
      if (!context) {
        return res.status(400).json({ error: 'Context is required' });
      }

      const subjects = await generateAISubjects(context, targetAudience);
      res.json({ subjects });
    } catch (error: any) {
      console.error('Subject generator error:', error);
      res.status(500).json({ error: 'Failed to generate subject lines' });
    }
  });

  // Templates API
  app.get('/api/templates', (req, res) => {
    res.json({ templates: db.getTemplates() });
  });

  app.post('/api/templates/use/:id', (req, res) => {
    const { id } = req.params;
    db.incrementTemplateUses(id);
    res.json({ success: true });
  });

  // Saved Emails API
  app.get('/api/saved-emails', (req, res) => {
    const userId = (req.query.userId as string) || 'usr_demo';
    res.json({ savedEmails: db.getSavedEmails(userId) });
  });

  app.post('/api/saved-emails', (req, res) => {
    const emailData = req.body;
    const newSaved = db.addSavedEmail({
      id: 'saved_' + Date.now(),
      userId: emailData.userId || 'usr_demo',
      title: emailData.title || emailData.subject || 'Saved Email Draft',
      subject: emailData.subject || '',
      body: emailData.body || '',
      closing: emailData.closing || '',
      signature: emailData.signature || '',
      fullContent: emailData.fullContent || `${emailData.subject}\n\n${emailData.body}`,
      category: emailData.category || 'Custom',
      tone: emailData.tone || 'Professional',
      language: emailData.language || 'English',
      isFavorite: !!emailData.isFavorite,
      createdAt: new Date().toISOString(),
      tags: emailData.tags || [],
    });
    res.json({ savedEmail: newSaved });
  });

  app.delete('/api/saved-emails/:id', (req, res) => {
    const success = db.deleteSavedEmail(req.params.id);
    res.json({ success });
  });

  app.post('/api/saved-emails/:id/favorite', (req, res) => {
    const updated = db.toggleFavoriteSavedEmail(req.params.id);
    res.json({ savedEmail: updated });
  });

  // Email History API
  app.get('/api/history', (req, res) => {
    const userId = (req.query.userId as string) || 'usr_demo';
    res.json({ history: db.getHistory(userId) });
  });

  // User Stats & Dashboard API
  app.get('/api/user/analytics', (req, res) => {
    res.json({
      weeklyUsage: db.getWeeklyUsage(),
      monthlyUsage: db.getMonthlyUsage(),
    });
  });

  // Admin Endpoints
  app.get('/api/admin/stats', (req, res) => {
    res.json({
      stats: db.getAdminStats(),
      users: db.getUsersList(),
      logs: db.getLogs(),
    });
  });

  // Vite Dev Server / Static Production Server
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 MailCraft Server running at http://localhost:${PORT}`);
  });
}

startServer();
